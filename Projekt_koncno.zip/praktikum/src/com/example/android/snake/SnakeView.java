package com.example.android.snake;

import java.util.ArrayList;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

public class SnakeView extends TileView {

    private int mMode = READY;
    public static final int PAUSE = 0;
    public static final int READY = 1;
    public static final int RUNNING = 2;
    public static final int LOSE = 3;

    private int mDirectionX;
    private int mDirectionY;
    
    private int mDirectionX1;
    private int mDirectionY1;
    
    private int mDirectionX2;
    private int mDirectionY2;
    
    private int mDirection = NORTH;
    private int mNextDirection = NORTH;
    private static final int NORTH = 1;
    private static final int SOUTH = 2;
    private static final int EAST = 3;
    private static final int WEST = 4;

    private static final int RED_STAR = 1;
    private static final int YELLOW_STAR = 2;
    private static final int GREEN_STAR = 3;
    private static final int PACMAN = 4;
    private static final int ENEMY = 5;
    
    private long mScore = 0;
    private long mMoveDelay = 600;
    
    private TextView mStatusText;

    private Point mEnemy = new Point(mDirectionX1, mDirectionY1);
    private Point mEnemy1 = new Point(mDirectionX2, mDirectionY2);
    private Point mSnake = new Point(mDirectionX, mDirectionY);
    private RefreshHandler mRedrawHandler = new RefreshHandler();

    private ArrayList<Point> mCoinsList = new ArrayList<Point>();
    
    private String map =
            "################\n"
          + "#-#---##-------#\n"
          + "#---#----#####-#\n"
          + "#-####-#----#--#\n"
          + "#-#----#-##-#-##\n"
          + "#---##-#--#-#-##\n"
          + "#-#----#-##-#-##\n"
          + "#-####-#-------#\n"
          + "#-#----#-###-###\n"
		  + "#-#-##-#-#-#--##\n"
          + "#----------##--#\n"
          + "#-#-#-##-#----##\n"
          + "#---#-#--#-##-##\n"
          + "#-###-#-##--#--#\n"
          + "#-------###-#-##\n"
          + "#-#-###-------##\n"
          + "#-#-#-#-####-###\n"
		  + "#-#-#---#------#\n"
          + "#-#-#-#-#-#-##-#\n"
          + "#-#-#-#------#-#\n"
          + "#---#-#-####-#-#\n"
          + "#-#------------#\n"
          + "#-#####-#-#-#-##\n"
          + "#-------#------#\n"
          + "################\n";
    
    class Voz
    {
        public int x;
        public int y;
        public int f;
        public int g;
        public int h;
        public Voz prejsni;

        public Voz()
        {
            x = 0;
            y = 0;
            f = 0;
            f = 0;
            h = 0;
        }

        public Voz(int x1, int y1)
        {
            x = x1;
            y = y1;
            f = 0;
            f = 0;
            h = 0;
        }

        public Voz(int x1, int y1, int f1, int g1, int h1)
        {
            x = x1;
            y = y1;
            f = f1;
            f = g1;
            h = h1;
        }
    }
    
    private ArrayList<Point> vozlisca = new ArrayList<Point>();
    
    class RefreshHandler extends Handler 
    {

        @Override
        public void handleMessage(Message msg) 
        {
            SnakeView.this.update();
            SnakeView.this.invalidate();
        }

        public void sleep(long delayMillis) 
        {
        	this.removeMessages(0);
            sendMessageDelayed(obtainMessage(0), delayMillis);
        }
    };

    public SnakeView(Context context, AttributeSet attrs) 
    {
        super(context, attrs);
        initSnakeView();
   }

    public SnakeView(Context context, AttributeSet attrs, int defStyle) 
    {
    	super(context, attrs, defStyle);
    	initSnakeView();
    }

    private void initSnakeView() 
    {
        setFocusable(true);

        Resources r = this.getContext().getResources();
        
        resetTiles(6);
        loadTile(RED_STAR, r.getDrawable(R.drawable.redstar));
        loadTile(YELLOW_STAR, r.getDrawable(R.drawable.yellowstar));
        loadTile(GREEN_STAR, r.getDrawable(R.drawable.greenstar));
        loadTile(PACMAN, r.getDrawable(R.drawable.sd)); 
        loadTile(ENEMY, r.getDrawable(R.drawable.enemy)); 
    }

    private void initNewGame() 
    {
        mSnake.x = 1;
        mSnake.y = 23;
        mNextDirection = NORTH;
        
        mEnemy.x = 15;
        mEnemy.y = 2;
        
        mEnemy1.x = 2;
        mEnemy1.y = 2;
        
        mMoveDelay = 200;
        mScore = 0;
        
        Coins();
    }

    public Bundle saveState() 
    {
        Bundle map = new Bundle();
        
        map.putInt("mDirection", Integer.valueOf(mDirection));
        map.putInt("mNextDirection", Integer.valueOf(mNextDirection));
        map.putLong("mMoveDelay", Long.valueOf(mMoveDelay));
        map.putLong("mScore", Long.valueOf(mScore));
        map.putInt("mSnakeX", Integer.valueOf(mDirectionX));
        map.putInt("mSnakeY", Integer.valueOf(mDirectionY));
        return map;
    }

    public void restoreState(Bundle icicle) 
    {
        setMode(PAUSE);

        mDirection = icicle.getInt("mDirection");
        mNextDirection = icicle.getInt("mNextDirection");
        mMoveDelay = icicle.getLong("mMoveDelay");
        mScore = icicle.getLong("mScore");
        mSnake.x = icicle.getInt("mDirectionX");
        mSnake.y = icicle.getInt("mDirectionY");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent msg) 
    {

        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) 
        {
            if (mMode == READY | mMode == LOSE) 
            {
                initNewGame();
                setMode(RUNNING);
                update();
                return (true);
            }

            if (mMode == PAUSE) 
            {
                setMode(RUNNING);
                update();
                return (true);
            }

            mNextDirection = NORTH;
            
            return (true);
        }

        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) 
        {
            mNextDirection = SOUTH;
            
            return (true);
        }

        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) 
        {
            mNextDirection = WEST;
            return (true);
        }

        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 
        {
            mNextDirection = EAST;
            
            return (true);
        }

        return super.onKeyDown(keyCode, msg);
    }
    
    public void pathX(int x)
    {
    	int vrstica = 0;
    	int stolpec = 0;
    	
    	int newX = mSnake.x + x;
    	int newY = mSnake.y ;
    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    	
    		if(newX == vrstica && newY == stolpec && item =='-')
    		{
    			mSnake.x = mSnake.x + x;
    			return;
    		}
    		
    		else if (item == '-' || item == '#' || item == '+') 
            {
    			vrstica ++;
            }

    	}
    	return;
    }
    
    public void pathY(int y)
    {
    	int newX = mSnake.x;
    	int newY = mSnake.y + y;
    	
    	int vrstica = 0;
    	int stolpec = 0;
    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    		
    		if(newX == vrstica && newY == stolpec && item =='-')
    		{
    			mSnake.y = mSnake.y + y;
    			
    			return;
    		}
    		
    		else if (item == '-' || item == '#' || item == '+') 
            {
    			vrstica ++;
            }
            
    	 		
    	}
    	return;
    }
    
    public void setTextView(TextView newView) 
    {
        mStatusText = newView;
    }

    public void setMode(int newMode) 
    {
        int oldMode = mMode;
        mMode = newMode;

        if (newMode == RUNNING & oldMode != RUNNING) 
        {
            mStatusText.setVisibility(View.INVISIBLE);
            update();
            return;
        }

        Resources res = getContext().getResources();
        CharSequence str = "";
        if (newMode == PAUSE) 
        {
            str = res.getText(R.string.mode_pause);
        }
        if (newMode == READY)
        {
            str = res.getText(R.string.mode_ready);
        }
        if (newMode == LOSE) 
        {
            str = res.getString(R.string.mode_lose_prefix) + mScore
                  + res.getString(R.string.mode_lose_suffix);
        }

        mStatusText.setText(str);
        mStatusText.setVisibility(View.VISIBLE);
    }

    public void update()
    {
        if (mMode == RUNNING) 
        {
            clearTiles();         
            updateCoins();
            updateWalls();
            updateSnake();
            enemy();
         //   Astar();
            
            mRedrawHandler.sleep(mMoveDelay);
        }

    }
    
    public void pathX1(int x)
    {
    	int vrstica = 0;
    	int stolpec = 0;
    	
    	int newX = mEnemy.x + x;
    	int newY = mEnemy.y ;
    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    	
    		else if(newX == vrstica && newY == stolpec && item =='-')
    		{
    			mEnemy.x = mEnemy.x + x;
    			return;
    		}
    		
    		else if(newX == vrstica && newY == stolpec && item =='+')
    		{
    			mEnemy.x = mEnemy.x + x;
    			return;
    		}
    		
    		else if (item == '-' || item == '#' || item == '+') 
            {
    			vrstica ++;
            }

    	}
    	return;
    }
    
    public void pathY1(int y)
    {
    	int newX = mEnemy.x;
    	int newY = mEnemy.y + y;
    	
    	int vrstica = 0;
    	int stolpec = 0;
    
    	

    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    		
    		else if(newX == vrstica && newY == stolpec && item =='-')
    		{
    			mEnemy.y = mEnemy.y + y;
    			
    			return;
    		}
    		
    		else if(newX == vrstica && newY == stolpec && item =='+')
    		{
    			mEnemy.y = mEnemy.y + y;
    			return;
    		}
    		
    		else if (item == '-' || item == '#' || item == '+') 
            {
    			vrstica ++;
            }
            
    	
    	}
    	return;
    }
    
    public void enemy()
    {
    	if(mEnemy.equals(mSnake))
    	{
    		setMode(LOSE);
    	}
    	
    	if(mEnemy1.equals(mSnake))
    	{
    		setMode(LOSE);
    	}
    	
    	
	    if (mEnemy.x < mSnake.x) 
	    {
	    	pathX1(1);
	    	//mEnemy.x ++;
	    }
	    else if (mEnemy.x > mSnake.x)
	    {
	    	pathX1(-1);
	    	//mEnemy.x --;
	    }
	    else if (mEnemy.y < mSnake.y)
	    {
	    	pathY1(1);
	    	//mEnemy.y ++;
	    }
	    else if (mEnemy.y > mSnake.y)
	    {
	    	pathY1(-1);
	    	//mEnemy.y --;
	    }
	    
	    if (mEnemy1.x < mSnake.x) 
	    {
	    	pathX11(1);
	    	//mEnemy.x ++;
	    }
	    else if (mEnemy1.x > mSnake.x)
	    {
	    	pathX11(-1);
	    	//mEnemy.x --;
	    }
	    else if (mEnemy1.y < mSnake.y)
	    {
	    	pathY11(1);
	    	//mEnemy.y ++;
	    }
	    else if (mEnemy1.y > mSnake.y)
	    {
	    	pathY11(-1);
	    	//mEnemy.y --;
	    }
    	
    }
    
    
    public void pathX11(int x)
    {
    	int vrstica = 0;
    	int stolpec = 0;
    	
    	int newX = mEnemy1.x + x;
    	int newY = mEnemy1.y ;
    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    	
    		else if(newX == vrstica && newY == stolpec && item =='-')
    		{
    			mEnemy1.x = mEnemy1.x + x;
    			return;
    		}
    		
    		else if(newX == vrstica && newY == stolpec && item =='+')
    		{
    			mEnemy1.x = mEnemy1.x + x;
    			return;
    		}
    		
    		else if (item == '-' || item == '#' || item == '+') 
            {
    			vrstica ++;
            }

    	}
    	return;
    }
    
    public void pathY11(int y)
    {
    	int newX = mEnemy1.x;
    	int newY = mEnemy1.y + y;
    	
    	int vrstica = 0;
    	int stolpec = 0;
    
    	

    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    		
    		else if(newX == vrstica && newY == stolpec && item =='-')
    		{
    			mEnemy1.y = mEnemy1.y + y;
    			
    			return;
    		}
    		
    		else if(newX == vrstica && newY == stolpec && item =='+')
    		{
    			mEnemy1.y = mEnemy1.y + y;
    			return;
    		}
    		
    		else if (item == '-' || item == '#' || item == '+') 
            {
    			vrstica ++;
            }
            
    	
    	}
    	return;
    }
    
    
    private void updateWalls() 
    {
    	int vrstica = 0;
    	int stolpec = 0;
    	Point temp;
    	
    	for (int i = 0; i < map.length(); i++) 
    	{
    		char item = map.charAt(i);
    		
    		if (item == '\n') 
    		{
    			stolpec = stolpec + 1;
    			vrstica = 0;
    		}
    		
        	
    		else if (item == '-') 
            {
    			
    			temp = new Point();
    			temp.x = vrstica;
    			temp.y = stolpec;
    			vozlisca.add(temp); // dodam vsa prazna polja za vozli��a
    			
    			vrstica ++;
            }
    		
    		else if(item == '+')
    		{
    			vrstica ++;
    		}
    		
    		else if (item == '#') 
            {
    			setTile(GREEN_STAR, vrstica, stolpec);
    			
    			vrstica ++;
            }
    	 		
    	}
    	
    	
    }
    
    private void updateCoins() {
        
    	if(mCoinsList.contains(mSnake))
    	{
    		mScore = mScore + 1;
    		mCoinsList.remove(mSnake); // izbri�em cekin �e pridem na isto lokacijo kot je cekin
    	}
		
    	
    	for (Point c : mCoinsList) {
            setTile(RED_STAR, c.x, c.y);
        }
    }
    
    private void Coins()
    {
    	int vrstica = 0;
    	int stolpec = 0;
    	Point temp;
	
    	for (int i = 0; i < map.length(); i++) 
    	{
			char item = map.charAt(i);
			
			if (item == '\n') 
			{
				stolpec = stolpec + 1;
				vrstica = 0;
			}
			
			else if (item == '-') 
	        {
				temp = new Point();
				temp.x = vrstica;
				temp.y = stolpec;
				
				mCoinsList.add(temp);
				
				vrstica ++;
	        }
			
			else if(item == '+')
			{
				vrstica ++;
			}
			
			else if (item == '#') 
	        {		
				vrstica ++;
	        }
	 		
    	}
    	
    }

    private void updateSnake()
    {
        mDirection = mNextDirection;

        switch (mDirection) 
        {
	        case EAST: 
	        {
	        	pathX(1);
	        	//mSnake.x = mSnake.x + 1;
	            break;
	        }
	        case WEST: 
	        {
	        	pathX(-1);
	        	//mSnake.x = mSnake.x - 1;
	            break;
	        }
	        case NORTH: 
	        {
	        	pathY(-1);
	        	//mSnake.y = mSnake.y - 1;
	            break;
	        }
	        case SOUTH: 
	        {
	        	pathY(1);
	        	//mSnake.y = mSnake.y + 1;
	            break;
	        }
        }

        //if ((mSnake.x < 1) || (mSnake.y < 1) || (mSnake.x > mXTileCount - 2)
        //        || (mSnake.y > mYTileCount - 2)) 
        //{
        //    setMode(LOSE);
        //    return;
        //}
        
        setTile(PACMAN, mEnemy.x, mEnemy.y);
        
        setTile(YELLOW_STAR, mSnake.x, mSnake.y);
        
        setTile(ENEMY, mEnemy1.x, mEnemy1.y);
    }
    
    private void Astar(Point z_tocka, Point k_tocka)
    {
    	ArrayList<Voz> Odprtiseznam = new ArrayList<Voz>();
    	ArrayList<Voz> Zaprtseznam = new ArrayList<Voz>();
    	
    	boolean kon = true;
    	
    	Voz zacetek = new Voz(z_tocka.x, z_tocka.y);
        Voz konec = new Voz(k_tocka.x, k_tocka.y);
        
        zacetek.g = 0;
        zacetek.h = Manhattan(zacetek, konec);
        zacetek.f = zacetek.g + zacetek.h;
        
        Odprtiseznam.add(zacetek);

    }
    
    private int Manhattan(Voz z, Voz k)
    {
        return (Math.abs(z.x - k.x) + Math.abs(z.y - k.y));
    }

    private int razdalja(Voz a, Voz b)
    {
        if (a.x == b.x)
        {
            return Math.abs(a.y - b.y);
        }
        else if (a.y == b.y)
        {
            return Math.abs(a.x - b.x);
        }
        else
        {
            return 1;
        }
    }
    
}
